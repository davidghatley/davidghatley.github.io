Stem 7 Condensed · David Hatley · 2026-10-27

Stem 7 with every run of repeated columns collapsed: tables, labels and dense data.

Every run of identical columns in Stem 7 Regular collapses to one, so O narrows from five cells to three and M from seven to five while stems and bars keep their weight.

Collapsing breaks some things a rule can't fix, so they are drawn by hand: all ten figures sit on one 4-cell box so columns of numbers line up, the dashes step 2, 3 and 5 cells, and l and [ are kept apart from L and C.

Glyphs: 121. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
