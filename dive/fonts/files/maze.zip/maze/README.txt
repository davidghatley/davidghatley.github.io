Maze · David Hatley · 2026-10-27

Pip 57's cells joined into hollow corridors: every letter is a labyrinth.

Pip 57's 5×7 drawings, but cells are joined centre to centre instead of drawn as dots. Each join is a corridor 72 units wide with 20-unit walls.

Corners and junctions stay open inside, and only the free ends are walled, so you could trace each letter with a pencil.

Glyphs: 107. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
