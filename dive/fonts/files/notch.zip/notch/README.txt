Notch · David Hatley · 2026-10-27

A heavy, low-contrast display serif with ink traps cut into every join.

Straight strokes are rectangles with flat serifs; curves are a flat nib stamped along a skeleton. Stems are 176 units and hairlines 62, so the contrast is low and the colour is dark.

Ink traps are found, not drawn. The outline is grown and shrunk by 34 units, which fills every concave corner; those fills, and only the small ones, are cut back out a little deeper. Every join gets a notch, and the counters are left alone.

Glyphs: 54. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
