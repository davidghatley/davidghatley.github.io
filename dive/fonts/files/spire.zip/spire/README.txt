Spire · David Hatley · 2026-10-27

An ultra-condensed poster face: squared bowls at half width under a heavy round pen.

Hoop's skeletons with every arc pushed toward a superellipse (exponent 0.3), so bowls get straight sides, then squeezed to half width and stroked at 132 units with round ends.

Counters close to slots, which is the point: it fills a tall poster column edge to edge. Symbols that need room inside them (# % & @ * + ~) keep their full width, and every dot is exactly one stroke wide.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
