Cantilena · David Hatley · 2026-10-27

A display Didone drawn as Bézier outlines: hairline serifs, bracketed joins and ball terminals on thin necks.

Bowls are cubic superellipses, an outer curve minus an inner one, so the thick sides and the hairline tops and bottoms are exact. Serifs are thin slabs joined to the stem by circular brackets; arm ends taper into beaks with a concave inner edge; curve ends hang a ball terminal off a hairline neck.

Shapes that a broad pen would write, like S and the 2, are traced by stamping a flat nib along a skeleton, then refitted as smooth cubics. Full upper and lowercase, figures and the Spanish accents, with capitals and lowercase kerned separately.

Glyphs: 105. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
