Bulkhead · David Hatley · 2026-10-27

A wide stencil face for machines: cells at 1.5× width, steps filled, bars slit.

Pip 57's cells drawn 150 units wide and 100 tall. Wherever two cells touch only at a corner, the triangle between them is filled, so diagonals run at a clean slope instead of stepping.

A thin slit is cut through the middle of every horizontal bar three or more cells long, which reads as a stencil and keeps the wide bars from going flat.

Glyphs: 107. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
