Brick · David Hatley · 2026-10-27

A geometric gothic: octagonal skeletons under a square pen with mitred joins.

The same octagonal skeletons as Quire, at 62% width, stroked with a 168-unit square pen. Joins are mitred and ends are square, so every bowl turns in hard 45-degree facets.

Where Quire is written, Brick is built: the same letters, laid like masonry.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
