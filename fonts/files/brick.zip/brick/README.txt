Brick · David Hatley · 2026-10-27

A geometric gothic: octagonal skeletons under a square pen, bevelled where strokes meet.

Hoop's skeletons with every arc replaced by its 45-degree points, so bowls become octagons, at 74% width under a 132-unit square pen.

A stroke end that meets nothing gets a square cap; where strokes meet, the outside of the turn is filled with a bevel, so nothing pokes out of a joint. Each glyph is then cut flat at the lines its skeleton reaches, so diagonals stand on the baseline instead of hanging below it.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
