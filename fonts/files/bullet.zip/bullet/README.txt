Bullet · David Hatley · 2026-10-27

Wayfinding bullets: Hoop Bold capitals, figures and marks knocked out of a disc.

Every capital, figure and mark of Hoop Bold is scaled to 62% and subtracted from a 720-unit disc. Lowercase types the capitals, so a route name can't come out wrong.

Glyphs: 82. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
