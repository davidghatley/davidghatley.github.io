Tube 5 · David Hatley · 2026-10-27

Unicase capitals bent from one-cell tubes, like neon. Posters, signs and title cards.

Cells merge into one outline, then every convex corner bends on a curve of up to one cell. A one-cell stroke end gets two half-cell curves, which makes a round cap.

Concave corners stay sharp, so a bend keeps the stroke's width like a bent glass tube. B, D, E, F, P and R keep a flat back, which is what tells D from O.

Glyphs: 78. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
