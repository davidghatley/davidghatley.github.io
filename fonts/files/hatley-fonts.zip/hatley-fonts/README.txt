Hatley fonts · 2026-10-27

Stem 7             The pixel font drawn on the grid of my mark. Five sizes, zero grey pixels.
Stem 7 Wide        Stem 7 with every column and every gap doubled: titles that sit wide and calm.
Stem 7 Condensed   Stem 7 with every run of repeated columns collapsed: tables, labels and dense data.
Pip 57             A 5×7 dot-matrix face with a true lowercase. Departure boards and scoreboards.
Tube 5             Unicase capitals bent from one-cell tubes, like neon. Posters, signs and title cards.
Tick 35            A 3×5 micro face for HUD readouts and labels, sharp down to 16 px.
Hoop               A geometric monoline sans drawn from lines and one circle. The text face of this site.
Hoop Mono          Hoop fitted to one 600-unit cell, with slabs on i, j, l and r. Code and terminals.
Notch              A heavy, low-contrast display serif with ink traps cut into every join.
Quire              A textura written with a broad nib on octagonal skeletons.
Brick              A geometric gothic: octagonal skeletons under a square pen with mitred joins.
Spire              An ultra-condensed poster face: squared bowls at half width under a heavy round pen.
Hopscotch          A heavy, bouncy display face that never sets the same letter twice in a row.
Halfstep           Hoop Bold with its left half snapped to a pixel grid and its right half left smooth.
Slash              A heavy italic cut through by parallel knife lines, like folded ribbon.
Bullet             Wayfinding bullets: Hoop Bold capitals, figures and marks knocked out of a disc.
Maze               Pip 57's cells joined into hollow corridors: every letter is a labyrinth.
Bulkhead           A wide stencil face for machines: cells at 1.5× width, steps filled, bars slit.
