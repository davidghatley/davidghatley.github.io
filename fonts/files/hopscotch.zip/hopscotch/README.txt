Hopscotch · David Hatley · 2026-10-27

A heavy, bouncy display face that never sets the same letter twice in a row.

Every letter and figure has three cuts, each turned, nudged and scaled a little differently from a seed. A contextual-alternates feature (calt) cycles through them, so 'oooo' sets three different o's before it repeats.

Underneath it is Hoop at 150 units with slightly squared bowls, so the bounce sits on a steady skeleton.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
