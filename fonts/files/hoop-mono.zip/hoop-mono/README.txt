Hoop Mono · David Hatley · 2026-10-27

Hoop fitted to one 600-unit cell, with slabs on i, j, l and r. Code and terminals.

The same skeletons as Hoop, each centred in a 600-unit cell. Wide letters (m, w, M, W) are squeezed horizontally before stroking, so the stroke itself keeps its weight.

Narrow letters get slabs: i, j, l and r would float in a wide cell, so they get feet and flags the way terminal faces do.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
