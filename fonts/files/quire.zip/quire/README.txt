Quire · David Hatley · 2026-10-27

A textura written with a broad nib on octagonal skeletons.

Hoop's skeletons with every arc replaced by its 45-degree points, so bowls become octagons, then squeezed to half width.

The outline is a broad nib, 200 units by 16, held at 38 degrees and dragged along each skeleton. Verticals come out heavy, the diagonals that run with the nib come out hairline, and every stroke end is cut at the pen angle.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
