Tick 35 · David Hatley · 2026-10-27

A 3×5 micro face for HUD readouts and labels, sharp down to 16 px.

Capitals are three cells wide and five tall. M, N and W take four or five cells, because a three-cell M is a guess.

It is unicase: lowercase sets the capitals, so a label stays one height. At 16 px every cell is two pixels and nothing is grey.

Glyphs: 79. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
