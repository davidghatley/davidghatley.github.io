Stem 7 Wide · David Hatley · 2026-10-27

Stem 7 with every column and every gap doubled: titles that sit wide and calm.

Every column of Stem 7 Regular is doubled, so a one-cell stem becomes two cells while bars stay one cell tall. The side bearings and the space double too, so letters keep Regular's stem-to-gap rhythm instead of crowding.

Regular's kerning is doubled to match, and the one-cell dh ligature is switched off, the way Bold does it, because a thin mark among wide letters reads as a mistake.

Glyphs: 121. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
