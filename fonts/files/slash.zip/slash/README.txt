Slash · David Hatley · 2026-10-27

A heavy italic cut through by parallel knife lines, like folded ribbon.

Hoop's skeletons with squared bowls, sheared 14 degrees and stroked at 170 units with flat ends.

Then a set of parallel cuts, 30 units wide and 330 apart, rising at 34 degrees, is subtracted from every glyph. The cuts line up from letter to letter, so a word reads as one ribbon.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
