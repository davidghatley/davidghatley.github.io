Pip 57 · David Hatley · 2026-10-27

A 5×7 dot-matrix face with a true lowercase. Departure boards and scoreboards.

Every cell is its own round dot, 0.84 of a cell across, so dots never touch and letters read as lamps on a board.

Most 5×7 faces skip lowercase. Pip 57 has a five-row x-height and two-row descenders, so g, j, p, q and y hang below the line. It is monospaced on a six-cell advance.

Glyphs: 107. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
