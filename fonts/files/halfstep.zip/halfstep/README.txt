Halfstep · David Hatley · 2026-10-27

Hoop Bold with its left half snapped to a pixel grid and its right half left smooth.

Each Hoop Bold glyph is cut down its middle. The left half is redrawn as grid cells, half a stroke wide, wherever the cell's centre falls inside the letter; the right half keeps the vector outline.

The seam is the idea: every letter shows the bitmap it came from and the curve it became.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
