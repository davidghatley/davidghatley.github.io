Hoop · David Hatley · 2026-10-27

A geometric monoline sans drawn from lines and one circle. The text face of this site.

Every glyph is a skeleton of lines, arcs and dots on a 1000-unit em, stroked with round caps and joins and merged into one clean outline. Every lowercase bowl (a b d g o p q) is the same circle, which is what makes the face geometric.

Bold is the same skeletons stroked at 136 units instead of 88, with the skeleton moved inward so stems still land on the baseline and x-height. Kerning is read off the outlines: each pair's tightest gap is pulled toward the gap between two n's.

Glyphs: 108. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
