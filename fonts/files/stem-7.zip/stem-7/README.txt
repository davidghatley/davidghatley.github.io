Stem 7 · David Hatley · 2026-10-27

The pixel font drawn on the grid of my mark. Five sizes, zero grey pixels.



Glyphs: 121. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
