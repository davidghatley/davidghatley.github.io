Stem 7 · David Hatley · 2026-10-27

The pixel font drawn on the grid of my mark. Five sizes, zero grey pixels.

A pixel font that refuses to blur. Set it at 16, 32, 48, 72 or 120 px and every edge lands on a whole pixel. Other sizes work too. They just look disappointed in you.

Regular, a Bold drawn by hand, and Grid, a variable face that draws every cell as its own square. Tabular figures, curly quotes, dashes, arrows, the dh mark (type dh) and seven project glyphs in the private-use area. Version 1.001.

Glyphs: 121. Free under the SIL Open Font License 1.1 (OFL.txt).
Install the .ttf files on a desktop; use the .woff2 files on the web.
